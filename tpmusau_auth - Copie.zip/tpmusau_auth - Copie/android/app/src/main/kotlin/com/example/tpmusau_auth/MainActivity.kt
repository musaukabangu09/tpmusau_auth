package com.example.tpmusau_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
