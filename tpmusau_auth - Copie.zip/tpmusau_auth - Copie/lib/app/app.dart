import 'package:flutter/material.dart';
import '../view/login_page.dart';
import '../view/register_page.dart';
import '../view/home_page.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Auth',
      theme: ThemeData(
        primaryColor: const Color(0xFF5669FF),
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        fontFamily: 'Poppins',
      ),
      initialRoute: "/login",
      routes: {
        "/login": (context) => const LoginPage(),
        "/register": (context) => const RegisterPage(),
        "/home": (context) => const HomePage(),
      },
    );
  }
}